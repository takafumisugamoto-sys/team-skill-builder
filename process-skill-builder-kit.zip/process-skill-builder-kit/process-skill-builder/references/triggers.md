# 次の工程を自動で促す（hook）

利用者が「特定の操作の直後に次のskillを促したい」と希望した場合だけ読む。

## 対応範囲

現在はClaude Codeだけに対応する。Claude Codeは、hookの設定だけで特定のコマンドに絞れるため。Codex、GitHub Copilot、Cursorも、シェル実行の後に文脈を足すhookを持つが、コマンドの判定をスクリプトで書く必要があり、入力形式もツールごとに違う。これらのツールの利用者には、skill末尾の「次の工程」節で案内が届くことを伝え、hookは作らない。

## Claude Codeでの設定ドラフト

設定はファイルに書かず、ドラフトとしてチャットに示す。利用者が `.claude/settings.json` の `hooks` に自分で加える。

例: Issueを作った直後に、PR作成skillを使うか促す。

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "if": "Bash(gh issue create *)",
            "command": "echo '{\"hookSpecificOutput\":{\"hookEventName\":\"PostToolUse\",\"additionalContext\":\"Issueを作成しました。続けて <skill名> でPRを作るか、利用者に確認してください。\"}}'"
          }
        ]
      }
    ]
  }
}
```

置き換える箇所は2つ。`if` のコマンドを、きっかけにしたい操作に変える。`<skill名>` を次の工程のskill名に変える。

## 伝えること

- このhookは次のskillを「促す」だけで、自動では実行しない。実行するかは毎回利用者が決める。
- `if` による絞り込みは確実には効かないと、Claude Codeのドキュメントに書かれている。発火しないことがあっても、作業に支障が出ない用途に限る。
- 強制したい処理（必ずlintを通すなど）には使わない。そうした処理はCIで行う。
