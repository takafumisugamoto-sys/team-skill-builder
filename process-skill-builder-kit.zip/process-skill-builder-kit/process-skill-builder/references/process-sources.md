# 工程と規約の探索先

## 工程の一覧（既定）

| 番号 | 工程 | 想定するskillの例 |
|---|---|---|
| 1 | 要件定義 | 要件の整理、受入基準の書き出し |
| 2 | タスク分解 | 機能をPR単位のタスクに分ける |
| 3 | Issue作成 | テンプレートに沿ったIssueの起票 |
| 4 | コード変更 | 実装の規約に沿ったコードの作成 |
| 5 | PR作成 | PR本文、コミット、ブランチの作成 |
| 6 | セルフレビュー | PR作成前の自己点検 |
| 7 | レビュー | 他者の変更のレビュー |
| 8 | QA | テストの作成と動作確認 |
| 9 | マージ | マージ条件の確認と後片付け |
| 10 | リリース | タグ付け、リリースノート、デプロイ手順 |

利用者が改名した工程は新しい名前だけを使う。追加された工程は11番以降とし、探索先は名前と説明から最も近い既定の工程を借りる。どれを借りたかを結果に書く。

## 範囲の既定値

| 対象 | 既定 |
|---|---|
| git履歴 | 直近90日かつ最大300コミット。90日で30コミットに満たなければ1年まで広げる |
| コード | 工程に関係するパスのうち、直近90日に変更されたファイルを優先。1つの型につき10〜20件を見本にする |
| レビューコメント | 直近90日のマージ済み変更から、botとリリース用のPRを除いて最大30件。90日のPRが100件を超えるリポジトリでは、直近30日に絞る |
| モノレポ | Step 1で選ばれたディレクトリだけ。選ばれなければリポジトリ全体 |

直近に変更されたファイルを優先するのは、いま使われている書き方が現行の規約に最も近いため。古いコードには廃れた書き方が残っていることが多い。

## 工程別の探索先

全工程で、指示ファイル（`AGENTS.md`、`CLAUDE.md`、`.cursor/rules/`、`.github/copilot-instructions.md`、`.github/instructions/`）、`CONTRIBUTING.md`、既存skillは共通で読む。下の表はそれに加えて見る場所。

| 工程 | 明文化・強制設定 | コードの実態 | git履歴 | レビューコメントで拾う指摘 |
|---|---|---|---|---|
| 要件定義 | `docs/`、ADR（`docs/adr/` など）、仕様書のテンプレート | 見ない | 見ない | 見ない |
| タスク分解 | Issueテンプレート、`docs/` の開発フロー | 見ない | 1つのPRに含まれるコミット数とファイル数の分布 | PRの粒度、分け方への指摘 |
| Issue作成 | Issueテンプレート（`.github/ISSUE_TEMPLATE/`、`.gitlab/issue_templates/`）、ラベル定義 | 見ない | コミットでのIssue番号の参照形式 | 見ない |
| コード変更 | lint・formatter・型検査の設定、`docs/` のコーディング規約、ADR | 変更頻度の高いディレクトリの命名、構成、エラー処理、依存の向き | 見ない | 命名、設計、エラー処理への指摘 |
| PR作成 | PR・MRテンプレート、commitlint、pre-commit、`CODEOWNERS` | 見ない | コミットメッセージの形式、ブランチ名、マージコミットのタイトル | PR本文、粒度、説明不足への指摘 |
| セルフレビュー | lint・CIの設定、チェックリストの文書、既存のレビュー観点 | 直近の変更ファイル | 「指摘対応」「fix lint」のようなコミット | 繰り返し出ている指摘全般 |
| レビュー | `CODEOWNERS`、レビュー指針の文書 | 直近の変更ファイル | 見ない | 指摘の書き方、観点、重大度の付け方 |
| QA | テスト設定（jest、vitest、pytest、rspec、playwright など）、CIのテストジョブ | テストファイルの配置、命名、構造、モックの使い方 | テスト追加を伴うコミットの割合 | テスト不足、テストの書き方への指摘 |
| マージ | ブランチ保護の説明文書、CIの必須ジョブ、マージ方式の記述 | 見ない | マージコミットの形式（squash、merge、rebase） | 見ない |
| リリース | リリース用のworkflow、`CHANGELOG.md`、バージョン設定 | 見ない | 直近20件のタグの形式、リリースコミットの形式 | 見ない |

「見ない」は、その工程の規約の根拠になりにくいため。時間を使う価値が低い。

## Findy Libraryの対応ページ

| 工程 | ページ（`https://lib.findy.co.jp` 以下） | MCPでの検索語 |
|---|---|---|
| 要件定義 | 該当なし | — |
| タスク分解、Issue作成 | `/ja/development/task-breakdown` | タスク分解 |
| コード変更 | `/ja/development/modifiability`、`/ja/development/refactoring` | 変更容易性、リファクタリング |
| PR作成 | `/ja/development/pull-request` | プルリクエスト 粒度 |
| セルフレビュー、レビュー | `/ja/development/code-review` | セルフレビュー、コードレビュー 観点 |
| QA | `/ja/development/testing`、`/ja/frontend/testing-strategy`、`/ja/frontend/e2e-testing` | テストコード、テスト戦略 |
| マージ | `/ja/development/pull-request`、`/ja/development/ci-cd` | プルリクエスト、CI/CD |
| リリース | `/ja/development/release-strategy`、`/ja/development/ci-cd` | リリース戦略 |

読み方は次の優先順にする。

1. Findy LibraryのMCP（`https://lib.findy.co.jp/mcp`、認証不要）が使えれば、それを使う。
   - `search_findy_library` に検索語と `language: "ja"` を渡すと、節ごとの本文とリンクが返る。
   - ページ全体を読むときは、`query_docs_filesystem_findy_library` に `cat /ja/development/pull-request.mdx` のようなコマンドを渡す（パスは上の表のページに `.mdx` を付けたもの）。`ls /ja/development` で一覧も取れる。
2. MCPがなければ、ページのパスに `.md` を付けたURL（例: `https://lib.findy.co.jp/ja/development/pull-request.md`）をWeb取得で読む。見つからなければ `https://lib.findy.co.jp/_llms/ja.txt` の索引で現在のパスを探す。
3. どちらもできなければ、URLだけを書き、「Libraryの本文は未確認」と結果に残す。読んでいない内容を要約しない。

skillに書くのは、要点1行、URL、MCPでの検索語までにする。Libraryの利用規約は複製の再配布を禁じているため、本文は転記しない。生成したskillは、使うたびにMCPで最新の本文を読む（`references/skill-template.md` の「参考にする実践知」節）。

### Findy LibraryのMCPのつなぎ方

Step 0でMCPが使えないと分かった場合に、Step 6で利用者に提案する。チームの全員のエージェントがLibraryを読めるよう、リポジトリ単位の設定にする。設定ファイルの変更なので、利用者の承認を得てから行う。

- Claude Code: `claude mcp add --transport http --scope project findy-library https://lib.findy.co.jp/mcp`（リポジトリ直下の `.mcp.json` に書かれる。各メンバーは初回に接続を承認する）
- それ以外のツール: そのツールのMCP設定に、名前 `findy-library`、種類 HTTP、URL `https://lib.findy.co.jp/mcp` で登録するよう案内する。設定ファイルの書式はツールごとに違うため、エージェントが推測で書かない。

## Organization共通のテンプレート

GitHubでは、リポジトリにPRやIssueのテンプレートがなければ、Organizationの `.github` リポジトリにある共通のテンプレートが使われる。リポジトリ内に見つからず、Step 0で `gh` が使えるなら、次で確かめる。

```
gh api --method GET repos/<owner>/.github/contents/.github/PULL_REQUEST_TEMPLATE.md --jq .content
gh api --method GET repos/<owner>/.github/contents/.github/ISSUE_TEMPLATE --jq '.[].name'
```

出典は `<owner>/.github` のパスと行で記録する。

## CI設定の探索先

GitHubは `.github/workflows/`、GitLabは `.gitlab-ci.yml`。そのほか `bitbucket-pipelines.yml`、`Jenkinsfile`、`azure-pipelines.yml`、`.circleci/config.yml` を探す。

## レビューコメントの取得

GitHubでは `gh` の読み取り系コマンドだけを使う。マージ済みPRの一覧は `gh pr list --state merged --search "merged:>=YYYY-MM-DD" --json number --limit 30`、コメントは `gh api --method GET repos/{owner}/{repo}/pulls/{number}/comments` と `.../issues/{number}/comments` で取る。GitLabでは、マージ済みMRの番号を `glab mr list --merged -F json` で取り、各MRのコメントを `glab mr note list <番号> -F json --type diff` と `--type general` で取る。`glab mr note list` は実験的なコマンドのため、失敗したらレビューコメントを飛ばして続ける。
